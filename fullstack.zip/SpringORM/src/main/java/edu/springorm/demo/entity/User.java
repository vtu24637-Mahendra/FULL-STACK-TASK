package edu.springorm.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

//ORM--> Obj.mapped into a relation (table)
@Entity
public class User {
	@Id
	int uid;
	String pwd;
	public User(int uid, String pwd) {
		super();
		this.uid = uid;
		this.pwd = pwd;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", pwd=" + pwd + "]";
	}
	
	

}
