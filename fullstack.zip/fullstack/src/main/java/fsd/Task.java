package fsd;
import org.springframework.web.bind.annotation.*;
@RestController
public class Task {
	@GetMapping("/greet")
	public String show() {
		System.out.println("Greet endpoint called!");
		return "Srikar is nice person";
	}

}
