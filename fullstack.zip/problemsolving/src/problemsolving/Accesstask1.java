package problemsolving;

import java.util.Scanner;

public class Accesstask1 {
	public static void main(String[] args) {
		Scanner sr=new Scanner(System.in);
		System.out.print("enter size of element n : ");
		int n=sr.nextInt();
		int[] arr=new int[n];
		System.out.println("enter the elements : ");
		for(int i=0; i<n; i++) {
			arr[i]=sr.nextInt();
		}
		System.out.println("enter index value : ");
		int index=sr.nextInt();
		if(index>0 && index<n) {
			System.out.println(+index+"is"+arr[index]);
		}
		else {
			System.out.println("enter correct index😊😊😊");
		}
		sr.close();
	}


}
