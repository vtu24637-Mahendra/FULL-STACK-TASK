package problemsolving;

import java.util.Scanner;

public class Binarysearch {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the elements : ");
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		int d=left+right/2;
		sc.close();
	}

}
